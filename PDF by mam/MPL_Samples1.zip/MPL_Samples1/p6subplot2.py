
import matplotlib.pyplot as plt
fobj=plt.figure(figsize=(8,8),facecolor='0')
spobj=fobj.add_subplot(3,2,1)
plt.show()
