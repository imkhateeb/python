
import matplotlib.pyplot as plt
fobj1=plt.figure(figsize=(8,4),facecolor='#00FF00')
fobj2=plt.figure(figsize=(8,8),facecolor='#00FFFF')
spobj1=fobj1.add_subplot(111)
spobj2=fobj2.add_subplot(224)
plt.show()
