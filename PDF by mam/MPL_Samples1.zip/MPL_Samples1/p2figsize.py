
import matplotlib.pyplot as plt
fobj=plt.figure(figsize=(10,6))
plt.show()
