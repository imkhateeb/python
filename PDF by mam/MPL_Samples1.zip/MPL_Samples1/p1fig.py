
import matplotlib.pyplot as plt
fobj=plt.figure()
plt.show()
