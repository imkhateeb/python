
import matplotlib.pyplot as plt
fobj=plt.figure(figsize=(6,4),facecolor='0.5')
plt.show()
