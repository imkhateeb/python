
import matplotlib.pyplot as plt
fobj=plt.figure(figsize=(10,6),facecolor='#FF0000')  
print(fobj)
plt.show()
